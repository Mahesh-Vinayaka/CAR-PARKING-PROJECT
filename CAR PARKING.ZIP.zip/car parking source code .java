import java.util.Scanner;
abstract class Parking {
    protected Car[] cars;
    protected int carCount;
    protected int capacity;
    public Parking(int capacity) {
        this.capacity = capacity;
        cars = new Car[capacity];
        carCount = 0;
    }
    abstract void parkCar(Car car);
    abstract void removeCar(String carNumber);
    abstract void viewParkedCars();
    abstract void calculateFee(String carNumber, int outTime);
}
class MallParking extends Parking {
    public MallParking(int capacity) {
        super(capacity);
    }
    @Override
    void parkCar(Car car) {
        if (carCount < capacity) {
            cars[carCount++] = car;
            System.out.println("Car parked: " + car.getCarNumber());
        } else {
            System.out.println("Parking lot is full, cannot park more cars.");
        }
    }
    @Override
    void removeCar(String carNumber) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].getCarNumber().equalsIgnoreCase(carNumber)) {
                System.out.println("Car removed: " + cars[i].getCarNumber());
                for (int j = i; j < carCount - 1; j++) {
                    cars[j] = cars[j + 1];
                }
                cars[--carCount] = null;
                return;
            }
        }
        System.out.println("Car not found.");
    }
    @Override
    void viewParkedCars() {
        System.out.println("Parked cars:");
        for (int i = 0; i < carCount; i++) {
            System.out.println(cars[i]);
        }
    }
    @Override
    void calculateFee(String carNumber, int outTime) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].getCarNumber().equalsIgnoreCase(carNumber)) {
                int inTime = cars[i].getInTime();
                int duration = outTime - inTime;
                int fee = 0;
                if (duration <= 1) {
                    fee = 30;
                } else if (duration <= 2) {
                    fee = 50;
                } else {
                    fee = 50 + (duration - 2) * 20; // Assuming an additional ₹20 for every hour after 2 hours
                }
                System.out.println("Parking fee for car " + carNumber + " is ₹" + fee);
                return;
            }
        }
        System.out.println("Car not found.");
    }
}
class Car {
    private String carNumber;
    private int inTime;

    public Car(String carNumber, int inTime) {
        this.carNumber = carNumber;
        this.inTime = inTime;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public int getInTime() {
        return inTime;
    }

    @Override
    public String toString() {
        return "Car[Car Number: " + carNumber + ", In Time: " + inTime + "]";
    }
}

public class Main {
    public static void main(String[] args) {
        MallParking parking = new MallParking(100); // Assuming a parking capacity of 100 cars
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMall Car Parking System Menu:");
            System.out.println("1. Park Car");
            System.out.println("2. Remove Car");
            System.out.println("3. View Parked Cars");
            System.out.println("4. Calculate Fee");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter car Number: ");
                    String carNumber = scanner.nextLine();
                    System.out.print("Enter in time: ");
                    int inTime = scanner.nextInt();
                    parking.parkCar(new Car(carNumber, inTime));
                    break;
                case 2:
                    System.out.print("Enter car car Number to remove: ");
                    carNumber = scanner.nextLine();
                    parking.removeCar(carNumber);
                    break;
                case 3:
                    parking.viewParkedCars();
                    break;
                case 4:
                    System.out.print("Enter car Number to calculate fee: ");
                    carNumber = scanner.nextLine();
                    System.out.print("Enter out time: ");
                    int outTime = scanner.nextInt();
                    parking.calculateFee(carNumber, outTime);
                    break;
                case 5:
                    System.out.println("Exiting the system.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 5);
    }
}